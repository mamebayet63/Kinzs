<?php
session_start();
require_once "src/includes/database.php";
require_once "src/includes/function.php";


$chambres = getThreeFirstchambres($pdo);
$residences = getResidence($pdo);


?>
<!doctype html>
<html lang="en">

<head>
    <title>Accueil - Kinz</title>
    <!-- Required meta tags -->
    <meta charset="utf-8" />
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1, shrink-to-fit=no" />

    <!-- Bootstrap CSS v5.2.1 -->
    <link rel="stylesheet" href="public/css/home.css">
    <style>
        @media (min-width: 992px) {
            .menu {
                margin-left: 150px;
            }
        }

        @media (max-width: 768px) {
            .menu {
                margin-left: 0px;
            }
        }

        @media (max-width: 576px) {
            .menu {
                margin-left: 0px;
            }
        }
    </style>
    <link
        href="
    https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/css/splide.min.css
    "
        rel="stylesheet" />
    <link href="
https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.min.css
" rel="stylesheet">
    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
        rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
        crossorigin="anonymous" />
</head>

<body>
    <header style="position: fixed;top:0;z-index:1000;background-color:white;width:100%">
        <nav class="navbar navbar-expand-lg bg-body-white shadow">
            <div class="container">
                <a class="navbar-brand" href="#">
                    <img src="public/images/logo.svg" alt="" style="height: 70px;">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 menu p-1 d-flex gap-3">
                        <li class="nav-item sidebar-link">
                            <a class="nav-link" href="index.php">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-link" href="src/views/users/chambre.php">Nos Chambres</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-link" href="src/views/users/propos.php">Qui sommes-nous ?</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link sidebar-link" href="src/views/users/contact.php">Contact</a>
                        </li>
                    </ul>
                    <div class="d-flex align-items-center gap-3">
                        <button class="btn bg-success d-flex align-items-center gap-4">
                            <span class="text-white fs-5">Telephone</span>
                            <i class="ri-phone-fill fes-5 text-white"></i>
                        </button>
                        <div style="width: 48px;height:48px" class="bg-success rounded-circle d-flex align-items-center justify-content-center">
                            <i class="ri-whatsapp-line text-white fs-4"></i>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <main style="margin-top: 98px;">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div style="width: 100%; height: 90vh;">
                        <div class="d-flex align-items-center p-0 p-sm-5" style="background-image: url(public/images/hero.svg); background-size: cover; background-repeat: no-repeat; background-position: center; height: 100%;">
                            <div>
                                <div class="w-100">
                                    <h1 class="text-white hero-title">Bienvenue aux Kinz Résidences</h1>
                                </div>
                                <p class="text-white mt-4 w-100 hero-para">
                                    Découvrez notre sélection de chambres confortables et modernes disponibles dans plusieurs résidences. Que vous soyez en voyage d'affaires, en vacances ou à la recherche d'un séjour prolongé, nous vous proposons des chambres adaptées à vos besoins. Parcourez nos options, réservez votre séjour en toute simplicité, et profitez d'un accueil chaleureux à votre arrivée. Notre mission est de vous offrir une expérience agréable et sans souci. Explorez nos résidences dès aujourd'hui et trouvez la chambre qui vous convient !
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="container ban z-3 d-none d-sm-block">
            <div class="row">
                <div class="col-12 baniere rounded-pill d-flex justify-content-center gap-5 p-2">
                    <div class="text-white d-flex flex-column justify-content-center gap-3 align-items-center">
                        <p class="fs-4 m-0">+ 50 Résidences</p>
                        <div class="baniere-icon rounded-circle">
                            <i class="ri-home-office-line fs-3"></i>
                        </div>
                    </div>
                    <div class="text-white d-flex flex-column justify-content-center gap-3 align-items-center">
                        <p class="fs-4 m-0">+200 Chambres</p>
                        <div class="baniere-icon rounded-circle">
                            <i class="ri-stack-line fs-3"></i>
                        </div>
                    </div>
                    <div class="text-white d-flex flex-column justify-content-center gap-3 align-items-center">
                        <p class="fs-4 m-0">120k Demande</p>
                        <div class="baniere-icon rounded-circle">
                            <i class="ri-group-3-line fs-3"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-column align-items-center justify-content-center mt-5">
                    <div class="line"></div>
                    <h2 class="mt-4 w-50 text-center">Explorez notre gallerie de chambre</h2>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-12 col-sm-6" style="height: 70vh;">
                    <div class="gallerie rounded d-flex justify-content-center align-items-center position-relative" style="background-image: url(public/images/gallerie-1.svg); background-size: cover; background-repeat: no-repeat; background-position: center; height: 100%;">
                        <div class="position-absolute bottom-0 end-0 d-flex gap-2 p-3">
                            <p class="m-0 text-white">Découvrir</p>
                            <i class="ri-arrow-right-circle-line text-white"></i>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-sm-6 d-flex flex-column justify-content-between">
                    <div class="row mt-3 mt-sm-0">
                        <div class="col-12 col-sm-12 col-lg-6" style="height: 30vh;">
                            <div class="gallerie1 rounded position-relative" style="background-image: url(public/images/gallerie-2.svg); background-size: cover; background-repeat: no-repeat; background-position: center; height: 100%;">
                                <div class="position-absolute bottom-0 end-0 d-flex gap-2 p-3">
                                    <p class="m-0 text-white">Découvrir</p>
                                    <i class="ri-arrow-right-circle-line text-white"></i>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-sm-12 col-lg-6 mt-3 mt-sm-0 d-block d-sm-none d-lg-block" style="height: 30vh;">
                            <div class="gallerie2 rounded position-relative" style="background-image: url(public/images/gallerie-3.png); background-size: cover; background-repeat: no-repeat; background-position: center; height: 100%;">
                                <div class="position-absolute bottom-0 end-0 d-flex gap-2 p-3">
                                    <p class="m-0 text-white">Découvrir</p>
                                    <i class="ri-arrow-right-circle-line text-white"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3 mt-sm-0">
                        <div class="col-12" style="height: 38vh;">
                            <div class="gallerie3 rounded position-relative" style="background-image: url(public/images/gallerie-4.svg); background-size: cover; background-repeat: no-repeat; background-position: center; height: 100%;">
                                <div class="position-absolute bottom-0 end-0 d-flex gap-2 p-3">
                                    <p class="m-0 text-white">Découvrir</p>
                                    <i class="ri-arrow-right-circle-line text-white"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 d-none d-sm-block d-lg-none mt-sm-4" style="height: 35vh;">
                    <div class="gallerie rounded" style="background-image: url(public/images/gallerie-3.png); background-size: cover; background-repeat: no-repeat; background-position: center; height: 100%;">
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-column align-items-center justify-content-center mt-5">
                    <div class="line"></div>
                    <h2 class="mt-4 w-50 text-center">Découvrir nos chambres et suites</h2>
                </div>
            </div>
            <!-- Partie chambre et suites -->
            <div class="row mt-5">
                <?php foreach ($chambres as $k => $chambre): ?>
                    <div class="col-12 col-sm-6 col-lg-4 shadow-sm position-relative p-2 hovera">
                        <div class="rounded" style="background-image: url(src/uploads/imgChambre/<?= $chambre["image"] ?>);background-size:cover;background-position:center;background-repeat:no-repeat;height:25vh"></div>
                        <p class="m-0 text-center p-1 bg-warning-subtle rounded mt-3"><?= $chambre["nom"] ?></p>
                        <p class="fw-bold mt-3">Caracteristique</p>
                        <div class="d-flex gap-2 mt-2">
                            <?php if ($chambre["television"] == "oui"): ?>
                                <div class="d-flex justify-content-center align-items-center bg-light rounded gap-2 p-1">
                                    <i class="ri-tv-line"></i>
                                    <span>Television</span>
                                </div>
                            <?php endif; ?>
                            <?php if ($chambre["comodite"] == "ventiller"): ?>
                                <div class="d-flex justify-content-center align-items-center bg-light rounded gap-2 p-1">
                                    <i class="ri-water-flash-line"></i>
                                    <span>Ventiller</span>
                                </div>
                            <?php else: ?>
                                <div class="d-flex justify-content-center align-items-center bg-light rounded gap-2 p-1"">
                                <i class=" ri-fridge-line"></i>
                                    <span>Climatiser</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mt-2">
                            <span class="fw-bold">Prix:</span>
                            <span><?= $chambre["prix"] ?>FCFA</span>
                        </div>
                        <p class="position-absolute top-0 end-0 text-white p-1 bg-<?php if ($chambre["status"] == 1) {
                                                                                        echo "success";
                                                                                    } else {
                                                                                        echo "danger";
                                                                                    } ?>">
                            <?php if ($chambre["status"] == 1): ?>
                                Disponible
                            <?php else: ?>
                                Rerserver
                            <?php endif; ?>
                        </p>
                        <div>
                            <span class="fw-bold">Dimension:</span>
                            <span><?= $chambre["dimension"] ?>(m)</span>
                        </div>
                        <a href="src/views/users/detailsChambre.php?id=<?= $chambre["ID_Chambre"] ?>" class="text-decoration-none text-black">
                            <div class="d-flex justify-content-end align-items-center gap-2 mt-3">
                                <span>Voir details</span>
                                <i class="ri-arrow-right-circle-line"></i>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-column align-items-center justify-content-center mt-5">
                    <div class="line"></div>
                    <h2 class="mt-4 w-50 text-center">Découvrir nos résidences</h2>
                </div>
            </div>
            <div class="row mt-5">
                <section class="splide" id="splide" aria-labelledby="carousel-heading">
                    <div class="splide__track">
                        <ul class="splide__list">
                            <?php foreach ($residences as $residence): ?>
                                <li class="splide__slide">
                                    <div
                                        class="rounded position-relative"
                                        style="
                                            background-image: url(src/uploads/imgResidence/<?= $residence["couverture"] ?>);
                                            background-repeat: no-repeat;
                                            background-size: cover;
                                            background-position: center;
                                            height: 50vh;
                                ">
                                        <div class=" mt-3 rounded d-flex justify-content-center align-items-center text-white position-absolute top-0 end-0">
                                            <p class="p-2 bg-warning rounded">
                                                <?= $residence["nom"] ?>
                                            </p>
                                        </div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </section>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-12 d-flex flex-column align-items-center justify-content-center mt-5">
                    <div class="line"></div>
                    <h2 class="mt-4 w-50 text-center">Témoignages</h2>
                </div>
            </div>
            <div class="row mt-5">
                <section class="splide" id="splide2" aria-labelledby="carousel-heading">
                    <div class="splide__track">
                        <ul class="splide__list">
                            <li class="splide__slide">
                                <div class="shadow p-2">
                                    <img
                                        class="p-2 rounded-circle"
                                        src="public/images/testi-4.svg"
                                        alt=""
                                        style="border: solid 2px var(--btn-color)" />
                                    <p class="fw-bold mt-3">Michael</p>
                                    <span>
                                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Obcaecati quidem mollitia accusamus debitis voluptates animi, nihil sint odio, excepturi dolorem eum. Esse animi asperiores recusandae iusto, earum vitae doloremque repudiandae?
                                    </span>
                                    <div class="d-flex gap-2 mt-3">
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                    </div>
                                </div>
                            </li>
                            <li class="splide__slide">
                                <div class="shadow p-2">
                                    <img
                                        class="p-2 rounded-circle"
                                        src="public/images/testi-2.svg"
                                        alt=""
                                        style="border: solid 2px var(--btn-color)" />
                                    <p class="fw-bold mt-3">Esther Howard</p>
                                    <span>
                                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nemo culpa debitis voluptates officia quos accusamus ipsam fugiat quibusdam nisi nam quo blanditiis error, magnam ea repellat quis perspiciatis dolorum incidunt?
                                    </span>
                                    <div class="d-flex gap-2 mt-3">
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                    </div>
                                </div>
                            </li>
                            <li class="splide__slide">
                                <div class="shadow p-2">
                                    <img
                                        class="p-2 rounded-circle"
                                        src="public/images/testi-1.svg"
                                        alt=""
                                        style="border: solid 2px var(--btn-color)" />
                                    <p class="fw-bold mt-3">Darlene Robertson</p>
                                    <span>
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam a ratione minima nemo numquam, qui doloremque ipsam nulla aliquid accusamus totam nisi. Suscipit a quidem neque! Dignissimos assumenda ex excepturi.
                                    </span>
                                    <div class="d-flex gap-2 mt-3">
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                    </div>
                                </div>
                            </li>
                            <li class="splide__slide">
                                <div class="shadow p-2">
                                    <img
                                        class="p-2 rounded-circle"
                                        src="public/images/testi-2.svg"
                                        alt=""
                                        style="border: solid 2px var(--btn-color)" />
                                    <p class="fw-bold mt-3">Kristin Watson</p>
                                    <span>
                                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium, ullam aspernatur. Animi veritatis consequatur, necessitatibus cumque ut dolores sint voluptas quis omnis reiciendis alias esse vero. Sint molestias tempora ipsam?
                                    </span>
                                    <div class="d-flex gap-2 mt-3">
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                    </div>
                                </div>
                            </li>
                            <li class="splide__slide">
                                <div class="shadow p-2">
                                    <img
                                        class="p-2 rounded-circle"
                                        src="public/images/testi-3.svg"
                                        alt=""
                                        style="border: solid 2px var(--btn-color)" />
                                    <p class="fw-bold mt-3">Joana Mills</p>
                                    <span>
                                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Pariatur labore fugit vero totam voluptas maxime quisquam repellat, magni incidunt, illum odio a voluptatibus reiciendis aperiam quas in perferendis aut sequi!
                                    </span>
                                    <div class="d-flex gap-2 mt-3">
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                        <div class="text-warning"><i class="ri-star-fill"></i></div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </section>
            </div>
        </div>
    </main>
    <footer style="margin-top: 150px;">
        <!-- place footer here -->
        <div class="p-4" style="background-image: url(public/images/footer-img.svg);background-size:cover;background-position:center;background-repeat:no-repeat;width:100%;">
            <div class="container">
                <div class="row">
                    <div class="col-12 d-flex justify-content-center">
                        <img src="public/images/logo.svg" alt="logo" style="height: 120px;">
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-12 col-sm-6 col-lg-4 d-flex flex-column gap-3">
                        <div>
                            <p class="m-0 fw-bold text-success fs-4">Telephone</p>
                            <span class="fs-5">
                                +221.77.757.57.57
                            </span>
                        </div>
                        <div class="d-flex flex-column gap-1">
                            <p class="m-0 fw-bold text-success fs-4">Adresse</p>
                            <span class="fs-5">
                                Keur Massar, Mtoa
                            </span>
                            <span class="fs-5">
                                Dakar, Sénégal
                            </span>
                        </div>
                        <div class="d-flex flex-column gap-1">
                            <p class="m-0 fw-bold text-success fs-4">Email</p>
                            <span class="fs-5">
                                Réservation.Dakar@
                            </span>
                            <span class="fs-5">
                                myblackpearl@gmail.com
                            </span>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4 d-flex flex-column gap-3 mt-5 mt-sm-0">
                        <div>
                            <p class="m-0 fw-bold text-success fs-4">Telephone</p>
                            <nav class="mt-3">
                                <ul class="list-unstyled d-flex flex-column gap-2">
                                    <li>
                                        <a href="#" class="text-decoration-none text-black fs-5">Actualites</a>
                                    </li>
                                    <li>
                                        <a href="#" class="text-decoration-none text-black fs-5">Recrutement</a>
                                    </li>
                                    <li>
                                        <a href="#" class="text-decoration-none text-black fs-5">Annonces</a>
                                    </li>
                                    <li>
                                        <a href="#" class="text-decoration-none text-black fs-5">FAQ</a>
                                    </li>
                                </ul>
                            </nav>
                            <div class="d-flex align-items-center gap-3">
                                <i class="ri-facebook-box-fill fs-2"></i>
                                <i class="ri-instagram-fill fs-2"></i>
                                <i class="ri-whatsapp-fill fs-2"></i>
                                <i class="ri-linkedin-box-fill fs-2"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-lg-4 d-flex flex-column gap-3 mt-5 mt-lg-0">
                        <p class="m-0 fw-bold text-success fs-4">S'inscrire a notre newsletter</p>
                        <form action="#" class="d-flex ">
                            <input type="email" name="email" class="form-control p-3" placeholder="Votre e-amil..">
                            <button type="submit" class="btn btn-warning text-white">Validez</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div style="background-color: rgba(0, 82, 72, 1) !important;" class="p-3">
            <p class="m-0 fw-bold text-white text-center">Tous droits réservés. | © 2024 Kinz</p>
        </div>
    </footer>
    <!-- Bootstrap JavaScript Libraries -->
    <script src="
    https://cdn.jsdelivr.net/npm/@splidejs/splide@4.1.4/dist/js/splide.min.js
    "></script>
    <script src="public/javascript/home.js"></script>
    <script
        src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>

    <script
        src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
        integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
        crossorigin="anonymous"></script>
</body>

</html>